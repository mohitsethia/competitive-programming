#include <iostream>
using namespace std;

vector <int> v;
int count(int i,string s){
    int count =0;
    if(s[i]=='\0'){
        return -1;
    }
    else{
        if(s[i]=='a'){
            //counting no. of continues a's
            while(s[i]=='a'){
                count++;
                i++;
            }
            v.push_back(count);
        }
        //if the string is of b
        else{
            while(s[i]=='b'){
                count++;
                i++;
            }
            //inserting -ve count of b's
            v.push_back(-count);
        }
    }
    return i;
}//end of func



int main() {
    string s;
    int k;
    cin>>s;
    cin>>k;
    int i=0;
    while(i>=0){
        i = count(i,s);
    }/*
    for(int j=0;j<v.size();j++)
   { cout<<v[j]<<endl;}*/
    int asum =0,bsum =0;
    int j=0;
    if(s[0]=='b'){
        i=1;
        j=0;
    }
    else {
        i=0;
        j=1;
    }
    
    for(;i<v.size();i+=2,j+=2){
        asum +=v[i];//finding total no. of a's
        //finding total no. of b's
        if(j<v.size())
        bsum+=v[j];
    }bsum = -bsum;
    //cout<<asum<<"\n"<<bsum<<endl;
//if total no. of a's is greater than or equal to total no. of b's
if(asum>=bsum){

//condition 1
if((asum+k)>=(asum+bsum)){
    cout<<(asum+bsum);
}
//condition 2
else{
    if(s[0]=='b')
    i=1;
    else 
    i=0;
    int maxsum=0;
    for(;i<v.size();i+=2)
    {int sum =0;
    int tmp =k;
    int j =i;
    while(tmp>=0 && j<v.size()){
        //if 'a' string encounters
        if(v[j]>0){
            sum+=v[j];
        }
        //if 'b' string encounters
        else{
            if((tmp+=v[j])>=0)
            sum-=v[j];
        }
        j++;
    }
    maxsum = max(maxsum,sum);
    
    }
    cout<<maxsum;
}
}
//if total no. of b's is greater than or equal to total no. of a's
else{
//condition 1
if((bsum+k)>=(asum+bsum)){
    cout<<(asum+bsum);
}
//condition 2
else{
    if(s[0]=='a')
    i=1;
    else 
    i=0;
    int maxsum=0;
    for(;i<v.size();i+=2)
    {int sum =0;
    int tmp =k;
    while(tmp>=0 && i<v.size()){
        //if 'b' string encounters
        if(v[i]<0){
            sum-=v[i];
        }
        //if 'a' string encounters
        else{
            if((tmp-=v[i])>=0)
            sum+=v[i];
        }
        i++;
    }
    maxsum = max(maxsum,sum);}
    cout<<maxsum;
}
}

}

