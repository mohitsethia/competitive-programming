#include<bits/stdc++.h>
using namespace std;
#define pp pair<int,pair<int,int>> 
vector<int> mergekarray(vector<vector<int>>arr,int k)
{
priority_queue<pp,vector<pp>,greater<pp>>pq;
vector<int>oarr;
for(int i=0;i<k;i++)
pq.push({arr[i][0],{i,0}});
while(!pq.empty())
{
    pp front=pq.top();
    pq.pop();
    oarr.push_back(front.first);
    int id=front.second.first;
    int j=front.second.second;
    if(j+1<arr[id].size())
    pq.push({arr[id][j+1],{id,j+1}});
}
return oarr;
}

int main() {
    int k,n;
    cin>>k>>n;
    vector<vector<int>>arr(k,vector<int>(n));
    for(int i=0;i<k;i++)
    {
        for(int j=0;j<n;j++)
        cin>>arr[i][j];
    }
    vector<int>output=mergekarray(arr,k);
    for(auto i:output)
    cout<<i<<" ";
	return 0;
}
