#include<iostream>
using namespace std;
#define MAX 1000
#define ll long long int
ll multiply(ll x, ll res[], ll res_size); 
  
void factorial(ll n) 
{ 
    ll res[MAX], count = 0; 
    res[0] = 1; 
    ll res_size = 1; 
    for (ll x=2; x<=n; x++) 
        res_size = multiply(x, res, res_size); 
   
    for (ll i = 0; i < res_size; i++){
        if(res[i] == 0){
            count++;
        }
        else
            break;
	}
    cout << count;
}
  
ll multiply(ll x, ll res[], ll res_size) 
{ 
    ll carry = 0; 
	for (ll i=0; i<res_size; i++) 
    { 
        ll prod = res[i] * x + carry; 
  
        res[i] = prod % 10;   
        carry  = prod/10;     
    } 
    while (carry) 
    { 
        res[res_size] = carry%10; 
        carry = carry/10; 
        res_size++; 
    } 
    return res_size; 
}
/*
ll trailzero(ll n){
	ll count = 0;
	while(n % 10 == 0){
		count++;
		n /= 10;
	}
	return count;
}
*/
int main () {
	ll n;
	cin >> n;
    factorial(n);
	return 0;
}
