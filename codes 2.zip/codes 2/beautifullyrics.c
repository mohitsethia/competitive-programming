#include<stdio.h>
int main(){
    int n;
    scanf("%d", &n);
    char s[1000000];
    for(i = 0; i < n; i++){
        scanf("%s", &s);
    }
    for(i = 0; i < n; i++){
        for(j = 0; j < strlen(s); j++){
            if(
        }
    }
    return 0;
}
