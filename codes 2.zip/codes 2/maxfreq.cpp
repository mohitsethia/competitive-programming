
#include <iostream>
#include<cstring>
using namespace std;

int main()
{
   int count, maxkey=0;
   char key,print;
   char a[1000];
   cin.getline(a,1000);
  
   
   for(int i =0;i<strlen(a);i++){
       
        key=a[i];
       count=1;
       for(int j=0;j<strlen(a)&&j!=i;j++){
           if(a[j]==key){
               count=count+1;
               
           }}
       if(count>maxkey){
           maxkey=count;
           print=key;
           
       }   
       
       else if (count==maxkey){
           print=a[0];
       }
      
   }cout<<print;
   
       return 0;
}


