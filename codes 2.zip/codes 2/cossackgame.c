#include<stdio.h>
int main(){
    char a[1000000], b[1000000];
    scanf("%s%s", a, b);
    int l = strlen(b);
    
    return 0;
}
