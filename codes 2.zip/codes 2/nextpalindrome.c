#include<stdio.h>
#include<string.h>
int main(){
    long long int t, i;
    scanf("%lld", &t);
    while(t--){
        scanf("%s", n);
        long long int l1 = strlen(n), count = 0;
        for(j = n+1; j <= 1000000; j++)
            for(i = 0; i < l1/2; i++){
                if(j[i] == j[l1 - i - 1])
                    count++;
                else
                    break;
            }
            if(count == l1/2)
                printf("%s\n", j);   
    }
    return 0;
}
