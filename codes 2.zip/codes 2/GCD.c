#include<stdio.h>
int rem(int a, int b){
int d;
while(d != 0){
d = a % b;
printf("%d", d);
return rem;
}
return 0;
}

int main(){
int a, b, ans;
scanf("%d%d", &a, &b);
ans = rem(a, b);
printf("%d", ans);
}
