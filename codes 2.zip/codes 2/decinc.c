#include<stdio.h>
int main(){
	int i, j, k;
		scanf("%d", &i);
	if(i % 4 == 0)
		printf("%d", i + 1);
	else
		printf("%d", i - 1);
}