a,b=input().split()
