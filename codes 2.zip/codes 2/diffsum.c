/*
#include<stdio.h>
int main(){
	int i, j, k, l;
	scanf("%d%d", &i, &j);
	k = i - j;
	l = i + j;
	if(i > j)
		printf("%d", k);
	else
		printf("%d", l);
}
*/
#include<stdio.h>
int main ()
 {
 int a,b,sum;

 printf("Enter a: ");
 scanf("%d",&a);
 printf("Enter b: ");
 scanf("%d",&b);

sum = a+b;
 printf("a+b=%d",sum);

 }