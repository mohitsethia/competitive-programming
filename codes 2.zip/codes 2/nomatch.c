#include<stdio.h>
int main(){
int T, n;
scanf("%d", &T);
while(T--){
scanf("%d", &n);
int a[n], i, sum = 0;
for(i = 0; i < n; i++){
scanf("%d", &a[i]);
}
for(i = 0; i < n; i++){


}
}
}
