a = int(input("Enter number of rows:"))
for i in range(a):
    print(end = ' ' * i)
    print("*" * (a-i))
    
