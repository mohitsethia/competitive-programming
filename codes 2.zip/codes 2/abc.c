#include<stdio.h>
int main(){
    int n, x, y;
    scanf("%d", &n);
    n = (2*x) + (3*y);
    printf("%d %d", x, y);
    return 0;
}
