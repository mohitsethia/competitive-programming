
public class solution {

	public static void main(String[] args) {
		System.out.println("Hello World!");
//		System.out.println("\n");
		System.out.println("New to Java?");	
	}
}