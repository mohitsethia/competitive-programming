#include<iostream>
#include<algorithm>
using namespace std;
int main(){
    int t;
    cin >> t;
    while(t--){
        int l, r;
        cin >> l >> r;
        cout << 2*(r-l)+1 << endl;
    }
    return 0;
}
