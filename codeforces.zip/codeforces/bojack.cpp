#include<iostream>
using namespace std;
int main(){
    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        cout << 2*n << endl << string(n, 'a') + string(n, 'b') << endl;
    }
    return 0;
}
