class Addition
{  
   private double num = 100;
   private int square(int a)
   {
	return a*a;
   }
} 
