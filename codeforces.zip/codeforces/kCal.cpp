#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main(){
    int A, B;
    cin >> A >> B;
    double ans = A*B /100.0;
    cout << ans << endl;
    return 0;
}
